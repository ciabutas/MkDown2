<?php
	/* Define authentication program */
	define("shellProgram","expect");
	//define("shellProgram","empty"); //DO NOT USE, empty will be added in a future version
	//define("shellProgram","python");
	
	/* Add your git config here
		Example:
		"http.sslVerify" => "false"
	*/
	function getConfig() {
		return array(
			
		);
	}
?>