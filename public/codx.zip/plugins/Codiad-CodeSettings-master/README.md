#CodeSettings

Create your own keybindings

##Installation

- Download the zip file and unzip it to your plugin folder.

##Example

![Example](http://andrano.de/Plugins/img/settings_dialog.jpg "Example")
![Example](http://andrano.de/Plugins/img/settings.jpg "Example")