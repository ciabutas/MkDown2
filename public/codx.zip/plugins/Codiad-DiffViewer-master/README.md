# Diff Viewer

This plugin allows to compare 2 files and to see all changes made in it. The "Compare File" option is available in the contextmenu of the filemanager component.

# Installation

- Download the zip file and extract it to your plugins folder
- Enable this plugin in the plugins manager in Codiad
