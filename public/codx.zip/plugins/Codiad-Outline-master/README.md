Outline
=======
Outline list plugin for Codiad-IDE
This plugin parses "function" and "class" tags of your source code and allows you to go to the line where it is defined.

Installation
============
Download the zip file and extract it to your plugins folder