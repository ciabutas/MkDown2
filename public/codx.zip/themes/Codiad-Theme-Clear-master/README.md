# Clear Theme

Clear Theme from lightux <https://github.com/lightux>

![Screen](https://raw.github.com/daeks/Codiad-Theme-Clear/master/screen.png "Screen")

# Installation

- Download the zip file and extract it to your theme folder
- Enable this theme in Codiad

# Note

This theme is not maintained from the original author anymore. I will update this theme time by time, but would really appreciate contributions to keep it updated. 
