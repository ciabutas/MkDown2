# codiad-ap-theme-ui

> a theme for Codeiad IDE based on atom seti ui

## Install

Just clone or download this repo to your `plugins` codiad directory.

[![screenshot](http://aparnet.ir/wp-content/uploads/2014/09/codiad-ap-theme-ui.png)](http://aparnet.ir/wp-content/uploads/2014/09/codiad-ap-theme-ui.png)
